<img src="./app/src/main/food_runner_logo-web.png" width="100"/>

# • FoodRunner

This is just a simple food delivery made using kotlin while taking the Internshala Android Development course.
